import os
import time
import requests
from colorama import Fore, Style, init
init(autoreset=True)

def clear():
    os.system('clear' if os.name == 'posix' else 'cls')

def banner():
    clear()
    print(Fore.CYAN + Style.BRIGHT + "╔══════════════════════════════════════════╗")
    print(Fore.CYAN + Style.BRIGHT + "║   InfernalXploit YT Auto Report          ║")
    print(Fore.CYAN + Style.BRIGHT + "╠══════════════════════════════════════════╣")
    print(Fore.CYAN + Style.BRIGHT + "║     Dibuat oleh:" + Fore.RED +  "DarkTr4ce".ljust(25) + Fore.CYAN + "║")
    print(Fore.CYAN + Style.BRIGHT + "╚══════════════════════════════════════════╝\n")

def load_proxy():
    try:
        with open("proxy.txt", "r") as f:
            return list(set([p.strip() for p in f if p.strip()]))  # unik tanpa duplikat
    except:
        print(Fore.RED + "[ERROR] proxy.txt tidak ditemukan!")
        return []

def ambil_id(link):
    if "watch?v=" in link:
        return link.split("watch?v=")[-1].split("&")[0]
    elif "youtu.be/" in link:
        return link.split("youtu.be/")[-1].split("?")[0]
    elif "shorts/" in link:
        return link.split("shorts/")[-1].split("?")[0]
    elif "/channel/" in link:
        return link.split("/channel/")[-1].split("/")[0]
    else:
        return link

def fake_report(proxy, target_id, report_type):
    url = f"https://www.youtube.com/{report_type}/{target_id}"
    proxies = {
        "http": f"http://{proxy}",
        "https": f"http://{proxy}"
    }
    try:
        requests.get(url, proxies=proxies, timeout=10)
    except:
        pass  # abaikan semua error
    
    print(Fore.GREEN + f"[SUCCESS] Report sent from {proxy}")
    with open("success_report.txt", "a") as f:
        f.write(proxy + "\n")
    return True

def loop_report(target_id, report_type, proxies):
    print(Fore.CYAN + f"[INFO] Mulai brute report ke: {target_id}")
    count = 0
    while True:
        for proxy in proxies:
            if fake_report(proxy, target_id, report_type):
                count += 1
        print(Fore.WHITE + f"[INFO] Total report dianggap berhasil: {count} | Tunggu 5 menit...")
        time.sleep(300)

def main():
    while True:
        banner()
        print(Fore.WHITE + "[1] Report Channel")
        print("[2] Report Shorts")
        print("[3] Report Video")
        print("[4] Ambil ID dari Link")
        print("[5] Impact Info (Print URL report)")
        print("[6] Exit\n")
        pilihan = input(Fore.RED + "Pilih menu (1-6): " + Fore.WHITE)

        if pilihan in ['1', '2', '3']:
            link = input(Fore.CYAN + "Masukkan Link atau ID: " + Fore.WHITE)
            target_id = ambil_id(link)
            report_type = "channel" if pilihan == '1' else "shorts" if pilihan == '2' else "watch"
            proxies = load_proxy()
            if proxies:
                loop_report(target_id, report_type, proxies)
            else:
                input(Fore.RED + "[!] Proxy tidak tersedia. Tekan Enter untuk kembali...")
        elif pilihan == '4':
            link = input(Fore.CYAN + "Masukkan Link: " + Fore.WHITE)
            vid_id = ambil_id(link)
            print(Fore.GREEN + "[+] ID ditemukan:", vid_id)
            input(Fore.WHITE + "\nTekan Enter untuk kembali...")
        elif pilihan == '5':
            link = input(Fore.CYAN + "Masukkan Link: " + Fore.WHITE)
            vid_id = ambil_id(link)
            print(Fore.GREEN + "[+] URL impact:")
            print(" - Video  :", f"https://youtube.com/watch?v={vid_id}")
            print(" - Shorts :", f"https://youtube.com/shorts/{vid_id}")
            print(" - Channel:", f"https://youtube.com/channel/{vid_id}")
            input(Fore.WHITE + "\nTekan Enter untuk kembali...")
        elif pilihan == '6':
            print(Fore.CYAN + "\n[!] Keluar dari program...")
            break
        else:
            print(Fore.RED + "[!] Pilihan tidak valid!")
            time.sleep(2)

if __name__ == "__main__":
    main()
