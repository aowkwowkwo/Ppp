import os
import subprocess
import random
import time
from datetime import datetime

# Warna
R = '\033[91m'
G = '\033[92m'
Y = '\033[93m'
B = '\033[94m'
C = '\033[96m'
W = '\033[97m'
P = '\033[95m'
RESET = '\033[0m'

def banner():
    os.system("clear" if os.name == "posix" else "cls")
    messages = [
        "Halo, dunia!", "Semangat terus!", "Jangan Dengarkan Apa Kata Mereka!",
        "Pemrograman Python itu seru!", "Semoga harimu menyenangkan!",
        "Tetap positif!", "Persetan Untuk Kang Recode!",
        "Koding Itu Menyenangkan!"
    ]
    pesan = random.choice(messages)
    print(f"{C}")
    os.system(f'cowsay -f eyes "{pesan}"')
    print(f"""{C}
════════════════════════════════════════════════════════════
         INFERNALXploit™ MEDIA DOWNLOADER NO WATERMARK
════════════════════════════════════════════════════════════
 SUPPORT : Youtube, Tiktok, IG, FB, Pinterest, Capcut, XNXX
════════════════════════════════════════════════════════════{W}""")


def download_media(url, format_choice):
    if not url:
        banner()
        print(f"{Y}[!] Masukkan URL terlebih dahulu! Contoh: https://vm.tiktok.com/xxx")
        return

    timestamp = int(time.time())
    file_base = f"/sdcard/InfernalXploit_{timestamp}"
    file_path = f"{file_base}.{format_choice}"

    print(f"{C}[•] Mengunduh media dari: {url}")
    print(f"{C}[•] Format yang dipilih: {format_choice}")

    try:
        if format_choice == "mp3":
            cmd = f'yt-dlp -x --audio-format mp3 -o "{file_base}.%(ext)s" "{url}"'
        elif format_choice == "mp4":
            cmd = f'yt-dlp -o "{file_base}.%(ext)s" "{url}"'
        elif format_choice in ["jpg", "png"]:
            cmd = f'yt-dlp --skip-download --write-thumbnail --convert-thumbnails {format_choice} -o "{file_base}" "{url}"'
        else:
            print(f"{R}[!] Format tidak valid. Pilih antara: mp3, mp4, jpg, png.")
            return

        subprocess.run(cmd, shell=True, check=True)
        print(f"{G}[✓] Media berhasil diunduh: {file_path}")

    except subprocess.CalledProcessError:
        print(f"{R}[!] Gagal mengunduh media dari URL tersebut.")

if __name__ == "__main__":
    banner()
    try:
        url = input(f"{C}[?] Masukkan URL Media: {W}").strip()
        format_choice = input(f"{C}[?] Pilih format (mp3/mp4/jpg/png): {W}").strip().lower()
        download_media(url, format_choice)
    except KeyboardInterrupt:
        print(f"\n{R}[!] Dibatalkan oleh pengguna.")
