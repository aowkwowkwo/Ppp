import requests
import os
import re
from bs4 import BeautifulSoup

def banner():
    os.system("cls" if os.name == "nt" else "clear")
    print("\033[1;96m██╗███╗   ██╗███████╗███████╗██████╗ ███████╗██╗     ██╗ ██████╗ ██╗")
    print("██║████╗  ██║██╔════╝██╔════╝██╔══██╗██╔════╝██║     ██║██╔════╝ ██║")
    print("██║██╔██╗ ██║█████╗  █████╗  ██████╔╝█████╗  ██║     ██║██║  ███╗██║")
    print("██║██║╚██╗██║██╔══╝  ██╔══╝  ██╔═══╝ ██╔══╝  ██║     ██║██║   ██║██║")
    print("██║██║ ╚████║███████╗███████╗██║     ███████╗███████╗██║╚██████╔╝██║")
    print("╚═╝╚═╝  ╚═══╝╚══════╝╚══════╝╚═╝     ╚══════╝╚══════╝╚═╝ ╚═════╝ ╚═╝\033[0m")
    print("\n\033[1;96m  Universal Uploader - Supports: Images, Videos, Audio, Documents, Archives")
    print("  Coded by: InfernalXploit | IG: instagram.com/infernalxploit")
    print("  -------------------------------------------------------------\033[0m\n")

def upload_to_top4top(file_path):
    if not os.path.exists(file_path):
        print("\033[1;96mError: File not found!\033[0m")
        return None
    
    excluded_ext = ['.html', '.htm', '.php', '.py', '.js', '.java', '.c', '.cpp', '.sh']
    file_ext = os.path.splitext(file_path)[1].lower()
    if file_ext in excluded_ext:
        print(f"\033[1;96mError: File extension {file_ext} not allowed!\033[0m")
        return None
    
    try:
        print(f"\033[1;96mUploading {file_path}...\033[0m")
        
        session = requests.Session()
        headers = {
            'User-Agent': 'Mozilla/5.0 (Linux; Android 10)',
            'Referer': 'https://top4top.io/'
        }
        
        session.get("https://top4top.io/", headers=headers)
        
        files = {
            'file_0_': (os.path.basename(file_path), open(file_path, 'rb'))
        }
        form_data = {
            'submitr': 'رفع الملفات'
        }
        
        response = session.post(
            "https://top4top.io/index.php",
            data=form_data,
            files=files,
            headers=headers
        )
        
        files['file_0_'][1].close()
        
        if response.status_code == 200:
            return extract_direct_link(response.text, file_ext)
        else:
            print(f"\033[1;96mUpload failed. Status code: {response.status_code}\033[0m")
            return None
            
    except Exception as e:
        print(f"\033[1;96mError: {str(e)}\033[0m")
        return None

def extract_direct_link(html_content, file_ext):
    soup = BeautifulSoup(html_content, 'html.parser')
    
    patterns = {
        'image': r'(https?://[ift]\.top4top\.io/.*?\.(jpg|jpeg|png|gif|bmp|webp))',
        'video': r'(https?://[ift]\.top4top\.io/.*?\.(mp4|avi|mov|mkv|flv|webm))',
        'audio': r'(https?://[ift]\.top4top\.io/.*?\.(mp3|wav|ogg|flac))',
        'document': r'(https?://[ift]\.top4top\.io/.*?\.(pdf|docx?|xlsx?|pptx?|txt))',
        'archive': r'(https?://[ift]\.top4top\.io/.*?\.(zip|rar|7z|tar|gz))'
    }
    
    for file_type, pattern in patterns.items():
        match = re.search(pattern, html_content, re.IGNORECASE)
        if match:
            print(f"\033[1;96mDetected {file_type} file\033[0m")
            return match.group(1)
    
    print("\033[1;96mCouldn't automatically detect direct link. Trying manual methods...\033[0m")
    return manual_link_extraction(html_content)

def manual_link_extraction(html_content):
    iframe = re.search(r'<iframe.*?src="(https?://.*?)"', html_content)
    if iframe:
        return iframe.group(1)
    
    input_url = re.search(r'<input[^>]*value="(https?://.*?)"', html_content)
    if input_url:
        return input_url.group(1)
    
    print("\n\033[1;96mPartial response for manual inspection:\033[0m")
    print(html_content[:1000] + "...")
    
    return input("\n\033[1;96mPlease enter the direct link manually (or press Enter to skip): \033[0m").strip() or None

if __name__ == "__main__":
    banner()
    while True:
        file_path = input("\033[1;96mFile path: \033[0m").strip('"').strip()
        
        if file_path.lower() == 'exit':
            break
            
        if file_path:
            direct_link = upload_to_top4top(file_path)
            if direct_link:
                print("\n\033[1;96mUpload successful!\033[0m")
                print(f"\033[1;96mDirect {os.path.splitext(file_path)[1][1:].upper()} link:\033[0m {direct_link}")
                
                with open("top4top_links.txt", "a") as f:
                    f.write(f"{file_path}|{direct_link}\n")
            else:
                print("\033[1;96mUpload failed or link not found.\033[0m")
